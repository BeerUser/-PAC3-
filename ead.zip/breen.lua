player_manager.AddValidModel( "Big Breen",                     "models/breenPM.mdl" )


